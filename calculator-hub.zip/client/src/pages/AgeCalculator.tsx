/**
 * Age Calculator Page
 * Design: Minimalist Precision
 */

import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function AgeCalculator() {
  const today = new Date();
  const [birthDate, setBirthDate] = useState(
    `${today.getFullYear() - 25}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
  );

  const result = useMemo(() => {
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();

    if (
      monthDiff < 0 ||
      (monthDiff === 0 && today.getDate() < birth.getDate())
    ) {
      age--;
    }

    // Calculate days and months
    let days = today.getDate() - birth.getDate();
    let months = today.getMonth() - birth.getMonth();

    if (days < 0) {
      months--;
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      days += lastMonth.getDate();
    }

    if (months < 0) {
      months += 12;
    }

    // Calculate total days lived
    const totalDays = Math.floor(
      (today.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24)
    );

    // Calculate next birthday
    let nextBirthday = new Date(today.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday < today) {
      nextBirthday = new Date(today.getFullYear() + 1, birth.getMonth(), birth.getDate());
    }
    const daysUntilBirthday = Math.ceil(
      (nextBirthday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
    );

    return {
      age,
      months,
      days,
      totalDays,
      daysUntilBirthday,
    };
  }, [birthDate]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Age Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Input Section */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Your Birth Date
            </h2>

            <div className="mb-8">
              <label className="block text-sm font-medium text-foreground mb-2">
                Select Date
              </label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
              />
            </div>
          </div>

          {/* Result Section */}
          <div className="border-precision bg-secondary rounded-lg p-8 mb-8">
            <h2 className="text-sm font-medium text-muted-foreground mb-6">
              YOUR AGE
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-card p-4 rounded-lg border-precision">
                <div className="font-mono-result text-accent">
                  {result.age}
                </div>
                <p className="text-xs text-muted-foreground mt-2">Years</p>
              </div>
              <div className="bg-card p-4 rounded-lg border-precision">
                <div className="font-mono-result text-accent">
                  {result.months}
                </div>
                <p className="text-xs text-muted-foreground mt-2">Months</p>
              </div>
              <div className="bg-card p-4 rounded-lg border-precision">
                <div className="font-mono-result text-accent">
                  {result.days}
                </div>
                <p className="text-xs text-muted-foreground mt-2">Days</p>
              </div>
              <div className="bg-card p-4 rounded-lg border-precision">
                <div className="font-mono-result text-accent">
                  {result.totalDays.toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground mt-2">Total Days</p>
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <p className="text-muted-foreground text-sm">
                <strong className="text-foreground">Next Birthday:</strong> In{' '}
                {result.daysUntilBirthday} days
              </p>
            </div>
          </div>

          {/* Fun Facts */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h3 className="font-semibold text-foreground mb-6">Fun Facts</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Hours Lived</span>
                <span className="font-mono-display text-foreground">
                  {(result.totalDays * 24).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Minutes Lived</span>
                <span className="font-mono-display text-foreground">
                  {(result.totalDays * 24 * 60).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Seconds Lived</span>
                <span className="font-mono-display text-foreground">
                  {(result.totalDays * 24 * 60 * 60).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Heartbeats (est.)</span>
                <span className="font-mono-display text-foreground">
                  {(result.totalDays * 24 * 60 * 60 * 1.2).toLocaleString('en-US', {
                    maximumFractionDigits: 0,
                  })}
                </span>
              </div>
            </div>
          </div>

          {/* Information */}
          <div className="border-precision bg-card rounded-lg p-8">
            <h3 className="font-semibold text-foreground mb-4">About Age Calculation</h3>
            <p className="text-sm text-muted-foreground mb-4">
              This calculator determines your exact age in years, months, and days based on
              your birth date. It also calculates the total number of days, hours, minutes,
              and seconds you have lived.
            </p>
            <p className="text-sm text-muted-foreground">
              The calculation takes into account leap years and the varying number of days in
              each month to ensure accuracy.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
