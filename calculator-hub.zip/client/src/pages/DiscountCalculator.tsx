import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateDiscount } from '@/lib/calculators-extended';

export default function DiscountCalculator() {
  const [originalPrice, setOriginalPrice] = useState(100);
  const [discountPercentage, setDiscountPercentage] = useState(20);

  const result = useMemo(() => {
    return calculateDiscount({ originalPrice, discountPercentage });
  }, [originalPrice, discountPercentage]);

  return (
    <CalculatorTemplate
      title="Discount Calculator"
      description="Calculate sale prices and savings"
      resultLabel="FINAL PRICE"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Original Price ($)</label>
          <input type="number" value={originalPrice} onChange={(e) => setOriginalPrice(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Discount (%)</label>
          <input type="number" value={discountPercentage} onChange={(e) => setDiscountPercentage(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
