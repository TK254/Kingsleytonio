/**
 * Percentage Calculator Page
 * Design: Minimalist Precision
 */

import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { calculatePercentage, calculatePercentageOf } from '@/lib/calculators';

type CalculationType = 'percentage' | 'percentageOf' | 'increase' | 'decrease';

export default function PercentageCalculator() {
  const [calcType, setCalcType] = useState<CalculationType>('percentage');
  const [value1, setValue1] = useState(25);
  const [value2, setValue2] = useState(100);

  const result = useMemo(() => {
    switch (calcType) {
      case 'percentage':
        return calculatePercentage({ value: value1, total: value2 });
      case 'percentageOf':
        return calculatePercentageOf(value1, value2);
      case 'increase':
        const increased = value2 + (value2 * value1) / 100;
        return {
          value: increased,
          formatted: increased.toFixed(2),
          unit: '',
        };
      case 'decrease':
        const decreased = value2 - (value2 * value1) / 100;
        return {
          value: decreased,
          formatted: decreased.toFixed(2),
          unit: '',
        };
      default:
        return { value: 0, formatted: '0', unit: '' };
    }
  }, [calcType, value1, value2]);

  const getLabel1 = () => {
    switch (calcType) {
      case 'percentage':
        return 'Value';
      case 'percentageOf':
        return 'Percentage (%)';
      case 'increase':
        return 'Increase (%)';
      case 'decrease':
        return 'Decrease (%)';
      default:
        return 'Value 1';
    }
  };

  const getLabel2 = () => {
    switch (calcType) {
      case 'percentage':
        return 'Total';
      case 'percentageOf':
        return 'Total';
      case 'increase':
        return 'Original Value';
      case 'decrease':
        return 'Original Value';
      default:
        return 'Value 2';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Percentage Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Calculation Type Selector */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8">
            {[
              { type: 'percentage' as const, label: 'What %?' },
              { type: 'percentageOf' as const, label: '% of' },
              { type: 'increase' as const, label: 'Increase' },
              { type: 'decrease' as const, label: 'Decrease' },
            ].map((item) => (
              <Button
                key={item.type}
                onClick={() => setCalcType(item.type)}
                variant={calcType === item.type ? 'default' : 'outline'}
                className="text-sm"
              >
                {item.label}
              </Button>
            ))}
          </div>

          {/* Input Section */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Calculate
            </h2>

            {/* Value 1 */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-foreground mb-2">
                {getLabel1()}
              </label>
              <input
                type="number"
                value={value1}
                onChange={(e) => setValue1(Number(e.target.value))}
                className="border-precision px-4 py-3 rounded-lg w-full font-mono-display text-lg"
              />
            </div>

            {/* Value 2 */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-foreground mb-2">
                {getLabel2()}
              </label>
              <input
                type="number"
                value={value2}
                onChange={(e) => setValue2(Number(e.target.value))}
                className="border-precision px-4 py-3 rounded-lg w-full font-mono-display text-lg"
              />
            </div>
          </div>

          {/* Result Section */}
          <div className="border-precision bg-secondary rounded-lg p-8 mb-8">
            <h2 className="text-sm font-medium text-muted-foreground mb-4">
              RESULT
            </h2>
            <div className="font-mono-result text-accent mb-4">
              {result.formatted}
              {calcType === 'percentage' && '%'}
            </div>
            <p className="text-muted-foreground text-sm">
              {calcType === 'percentage' &&
                `${value1} is ${result.formatted}% of ${value2}`}
              {calcType === 'percentageOf' &&
                `${value1}% of ${value2} is ${result.formatted}`}
              {calcType === 'increase' &&
                `${value2} increased by ${value1}% is ${result.formatted}`}
              {calcType === 'decrease' &&
                `${value2} decreased by ${value1}% is ${result.formatted}`}
            </p>
          </div>

          {/* Examples */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h3 className="font-semibold text-foreground mb-6">Examples</h3>
            <div className="space-y-4 text-sm">
              <div className="border-l-2 border-accent pl-4">
                <p className="font-medium text-foreground mb-1">
                  What percentage is 25 of 100?
                </p>
                <p className="text-muted-foreground">Answer: 25%</p>
              </div>
              <div className="border-l-2 border-accent pl-4">
                <p className="font-medium text-foreground mb-1">
                  What is 20% of 150?
                </p>
                <p className="text-muted-foreground">Answer: 30</p>
              </div>
              <div className="border-l-2 border-accent pl-4">
                <p className="font-medium text-foreground mb-1">
                  What is 100 increased by 10%?
                </p>
                <p className="text-muted-foreground">Answer: 110</p>
              </div>
              <div className="border-l-2 border-accent pl-4">
                <p className="font-medium text-foreground mb-1">
                  What is 200 decreased by 15%?
                </p>
                <p className="text-muted-foreground">Answer: 170</p>
              </div>
            </div>
          </div>

          {/* FAQ */}
          <div className="border-precision bg-card rounded-lg p-8">
            <h3 className="font-semibold text-foreground mb-4">FAQ</h3>
            <div className="space-y-4 text-sm">
              <div>
                <p className="font-medium text-foreground mb-1">
                  How do I calculate percentage?
                </p>
                <p className="text-muted-foreground">
                  Divide the part by the whole and multiply by 100: (Part / Whole) × 100
                </p>
              </div>
              <div>
                <p className="font-medium text-foreground mb-1">
                  What is a percentage increase?
                </p>
                <p className="text-muted-foreground">
                  The amount something grows by, expressed as a percentage of the original value.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
