import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateProfitMargin } from '@/lib/calculators-extended';

export default function ProfitMarginCalculator() {
  const [revenue, setRevenue] = useState(10000);
  const [cost, setCost] = useState(6000);

  const result = useMemo(() => {
    return calculateProfitMargin({ revenue, cost });
  }, [revenue, cost]);

  return (
    <CalculatorTemplate
      title="Profit Margin Calculator"
      description="Calculate profit margins"
      resultLabel="PROFIT MARGIN"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Revenue ($)</label>
          <input type="number" value={revenue} onChange={(e) => setRevenue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Cost ($)</label>
          <input type="number" value={cost} onChange={(e) => setCost(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
