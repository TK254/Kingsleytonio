import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateIdealWeight } from '@/lib/calculators-extended';

export default function IdealWeightCalculator() {
  const [height, setHeight] = useState(70);
  const [gender, setGender] = useState<'male' | 'female'>('male');

  const result = useMemo(() => {
    return calculateIdealWeight({ height, gender });
  }, [height, gender]);

  return (
    <CalculatorTemplate
      title="Ideal Weight Calculator"
      description="Calculate your ideal weight range"
      resultLabel="IDEAL WEIGHT"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Height (inches)</label>
          <input type="number" value={height} onChange={(e) => setHeight(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Gender</label>
          <select value={gender} onChange={(e) => setGender(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
      </div>
    </CalculatorTemplate>
  );
}
