/**
 * Compound Interest Calculator Page
 * Design: Minimalist Precision
 */

import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { calculateCompoundInterest } from '@/lib/calculators';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function CompoundInterestCalculator() {
  const [principal, setPrincipal] = useState(10000);
  const [rate, setRate] = useState(7);
  const [time, setTime] = useState(10);
  const [frequency, setFrequency] = useState(12);

  const result = useMemo(() => {
    return calculateCompoundInterest({ principal, rate, time, frequency });
  }, [principal, rate, time, frequency]);

  const finalAmount = principal + result.value;

  // Generate chart data
  const chartData = useMemo(() => {
    const data = [];
    for (let year = 0; year <= time; year++) {
      const yearResult = calculateCompoundInterest({
        principal,
        rate,
        time: year,
        frequency,
      });
      data.push({
        year,
        amount: principal + yearResult.value,
        interest: yearResult.value,
      });
    }
    return data;
  }, [principal, rate, time, frequency]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Compound Interest Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Input Section */}
          <div>
            <div className="border-precision bg-card rounded-lg p-8">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Investment Details
              </h2>

              {/* Principal */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Principal Amount ($)
                </label>
                <input
                  type="number"
                  value={principal}
                  onChange={(e) => setPrincipal(Number(e.target.value))}
                  className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                />
              </div>

              {/* Rate */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Annual Interest Rate (%)
                </label>
                <input
                  type="number"
                  value={rate}
                  onChange={(e) => setRate(Number(e.target.value))}
                  step="0.1"
                  className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                />
              </div>

              {/* Time */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Time Period (Years)
                </label>
                <input
                  type="number"
                  value={time}
                  onChange={(e) => setTime(Number(e.target.value))}
                  className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                />
              </div>

              {/* Compounding Frequency */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Compounding Frequency
                </label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(Number(e.target.value))}
                  className="border-precision px-3 py-2 rounded-lg w-full"
                >
                  <option value={1}>Annually</option>
                  <option value={2}>Semi-annually</option>
                  <option value={4}>Quarterly</option>
                  <option value={12}>Monthly</option>
                </select>
              </div>

              {/* Results */}
              <div className="border-t border-border pt-8 mt-8">
                <h3 className="text-sm font-medium text-muted-foreground mb-4">
                  INTEREST EARNED
                </h3>
                <div className="font-mono-result text-accent mb-6">
                  {result.formatted}
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Final Amount
                    </span>
                    <span className="font-mono-display text-foreground">
                      ${finalAmount.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Total Return
                    </span>
                    <span className="font-mono-display text-foreground">
                      {((result.value / principal) * 100).toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Chart Section */}
          <div>
            <div className="border-precision bg-card rounded-lg p-8">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Growth Over Time
              </h2>

              {chartData.length > 0 && (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis
                      dataKey="year"
                      stroke="#6b7280"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#f9fafb',
                        border: '1px solid #e5e7eb',
                        borderRadius: '0.5rem',
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="amount"
                      stroke="#4f46e5"
                      name="Total Amount"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}

              {/* FAQ */}
              <div className="mt-8 border-t border-border pt-8">
                <h3 className="font-semibold text-foreground mb-4">
                  What is Compound Interest?
                </h3>
                <p className="text-sm text-muted-foreground">
                  Compound interest is interest earned on both the principal and previously
                  earned interest. It's calculated at regular intervals and added to the
                  principal, creating exponential growth over time.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
