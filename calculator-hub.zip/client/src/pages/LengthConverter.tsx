import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { convertLength } from '@/lib/calculators-extended';

export default function LengthConverter() {
  const [value, setValue] = useState(1);
  const [from, setFrom] = useState<'mm' | 'cm' | 'm' | 'km' | 'in' | 'ft' | 'yd' | 'mi'>('m');
  const [to, setTo] = useState<'mm' | 'cm' | 'm' | 'km' | 'in' | 'ft' | 'yd' | 'mi'>('ft');

  const result = useMemo(() => {
    return convertLength({ value, from, to });
  }, [value, from, to]);

  return (
    <CalculatorTemplate
      title="Length Converter"
      description="Convert between length units"
      resultLabel="CONVERTED LENGTH"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Value</label>
          <input type="number" value={value} onChange={(e) => setValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">From</label>
          <select value={from} onChange={(e) => setFrom(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="mm">Millimeters</option>
            <option value="cm">Centimeters</option>
            <option value="m">Meters</option>
            <option value="km">Kilometers</option>
            <option value="in">Inches</option>
            <option value="ft">Feet</option>
            <option value="yd">Yards</option>
            <option value="mi">Miles</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">To</label>
          <select value={to} onChange={(e) => setTo(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="mm">Millimeters</option>
            <option value="cm">Centimeters</option>
            <option value="m">Meters</option>
            <option value="km">Kilometers</option>
            <option value="in">Inches</option>
            <option value="ft">Feet</option>
            <option value="yd">Yards</option>
            <option value="mi">Miles</option>
          </select>
        </div>
      </div>
    </CalculatorTemplate>
  );
}
