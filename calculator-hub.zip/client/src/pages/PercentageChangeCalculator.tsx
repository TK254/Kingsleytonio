import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculatePercentageChange } from '@/lib/calculators-extended';

export default function PercentageChangeCalculator() {
  const [oldValue, setOldValue] = useState(100);
  const [newValue, setNewValue] = useState(120);

  const result = useMemo(() => {
    return calculatePercentageChange({ oldValue, newValue });
  }, [oldValue, newValue]);

  return (
    <CalculatorTemplate
      title="Percentage Change Calculator"
      description="Calculate percentage increase or decrease"
      resultLabel="PERCENTAGE CHANGE"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Old Value</label>
          <input type="number" value={oldValue} onChange={(e) => setOldValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">New Value</label>
          <input type="number" value={newValue} onChange={(e) => setNewValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
