import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateDebtPayoff } from '@/lib/calculators-extended';

export default function DebtPayoffCalculator() {
  const [debtAmount, setDebtAmount] = useState(10000);
  const [monthlyPayment, setMonthlyPayment] = useState(300);
  const [annualInterestRate, setAnnualInterestRate] = useState(5);

  const result = useMemo(() => {
    return calculateDebtPayoff({ debtAmount, monthlyPayment, annualInterestRate });
  }, [debtAmount, monthlyPayment, annualInterestRate]);

  return (
    <CalculatorTemplate
      title="Debt Payoff Calculator"
      description="Calculate time to pay off debt"
      resultLabel="TIME TO PAYOFF"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Debt Amount ($)</label>
          <input type="number" value={debtAmount} onChange={(e) => setDebtAmount(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Monthly Payment ($)</label>
          <input type="number" value={monthlyPayment} onChange={(e) => setMonthlyPayment(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Annual Interest Rate (%)</label>
          <input type="number" value={annualInterestRate} onChange={(e) => setAnnualInterestRate(Number(e.target.value))} step="0.1" className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
