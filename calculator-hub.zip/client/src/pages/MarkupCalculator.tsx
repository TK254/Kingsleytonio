import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateMarkup } from '@/lib/calculators-extended';

export default function MarkupCalculator() {
  const [costPrice, setCostPrice] = useState(50);
  const [markupPercentage, setMarkupPercentage] = useState(30);

  const result = useMemo(() => {
    return calculateMarkup({ costPrice, markupPercentage });
  }, [costPrice, markupPercentage]);

  return (
    <CalculatorTemplate
      title="Markup Calculator"
      description="Calculate selling price with markup"
      resultLabel="SELLING PRICE"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Cost Price ($)</label>
          <input type="number" value={costPrice} onChange={(e) => setCostPrice(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Markup (%)</label>
          <input type="number" value={markupPercentage} onChange={(e) => setMarkupPercentage(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
