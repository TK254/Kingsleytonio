/**
 * Mortgage Calculator Page
 * Design: Minimalist Precision
 */

import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { calculateMortgage, calculateMortgageTotal } from '@/lib/calculators';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function MortgageCalculator() {
  const [principal, setPrincipal] = useState(300000);
  const [annualRate, setAnnualRate] = useState(6.5);
  const [years, setYears] = useState(30);

  const result = useMemo(() => {
    return calculateMortgage({ principal, annualRate, years });
  }, [principal, annualRate, years]);

  const totalPayment = useMemo(() => {
    return calculateMortgageTotal({ principal, annualRate, years });
  }, [principal, annualRate, years]);

  const totalInterest = totalPayment - principal;

  // Generate amortization chart data
  const chartData = useMemo(() => {
    const monthlyRate = annualRate / 100 / 12;
    const numberOfPayments = years * 12;
    let balance = principal;
    const data = [];

    for (let i = 1; i <= numberOfPayments; i += Math.ceil(numberOfPayments / 12)) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = result.value - interestPayment;
      balance -= principalPayment;

      data.push({
        month: i,
        principal: Math.max(0, balance),
        interest: interestPayment,
      });
    }

    return data;
  }, [principal, annualRate, years, result.value]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Mortgage Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Input Section */}
          <div>
            <div className="border-precision bg-card rounded-lg p-8">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Loan Details
              </h2>

              {/* Principal */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Loan Amount
                </label>
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="range"
                    min="10000"
                    max="1000000"
                    step="10000"
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="flex-grow"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">$</span>
                  <input
                    type="number"
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                  />
                </div>
              </div>

              {/* Interest Rate */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Annual Interest Rate (%)
                </label>
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="range"
                    min="0"
                    max="12"
                    step="0.1"
                    value={annualRate}
                    onChange={(e) => setAnnualRate(Number(e.target.value))}
                    className="flex-grow"
                  />
                </div>
                <input
                  type="number"
                  value={annualRate}
                  onChange={(e) => setAnnualRate(Number(e.target.value))}
                  step="0.1"
                  className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                />
              </div>

              {/* Loan Term */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Loan Term (Years)
                </label>
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="range"
                    min="1"
                    max="50"
                    step="1"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="flex-grow"
                  />
                </div>
                <input
                  type="number"
                  value={years}
                  onChange={(e) => setYears(Number(e.target.value))}
                  className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
                />
              </div>

              {/* Results */}
              <div className="border-t border-border pt-8 mt-8">
                <h3 className="text-sm font-medium text-muted-foreground mb-4">
                  MONTHLY PAYMENT
                </h3>
                <div className="font-mono-result text-accent mb-6">
                  {result.formatted}
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Total Payment
                    </span>
                    <span className="font-mono-display text-foreground">
                      ${totalPayment.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Total Interest
                    </span>
                    <span className="font-mono-display text-foreground">
                      ${totalInterest.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Chart Section */}
          <div>
            <div className="border-precision bg-card rounded-lg p-8">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Amortization Schedule
              </h2>

              {chartData.length > 0 && (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis
                      dataKey="month"
                      stroke="#6b7280"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#f9fafb',
                        border: '1px solid #e5e7eb',
                        borderRadius: '0.5rem',
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="principal"
                      stroke="#4f46e5"
                      name="Remaining Balance"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}

              {/* FAQ */}
              <div className="mt-8 border-t border-border pt-8">
                <h3 className="font-semibold text-foreground mb-4">
                  Common Questions
                </h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <p className="font-medium text-foreground mb-1">
                      What is a mortgage?
                    </p>
                    <p className="text-muted-foreground">
                      A mortgage is a loan used to purchase real estate, typically
                      repaid over 15-30 years.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">
                      How is interest calculated?
                    </p>
                    <p className="text-muted-foreground">
                      Interest is calculated monthly based on the remaining balance
                      and annual interest rate.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
