import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateSavingsGoal } from '@/lib/calculators-extended';

export default function SavingsGoalCalculator() {
  const [targetAmount, setTargetAmount] = useState(50000);
  const [monthlyContribution, setMonthlyContribution] = useState(500);
  const [annualInterestRate, setAnnualInterestRate] = useState(4);

  const result = useMemo(() => {
    return calculateSavingsGoal({ targetAmount, monthlyContribution, annualInterestRate });
  }, [targetAmount, monthlyContribution, annualInterestRate]);

  return (
    <CalculatorTemplate
      title="Savings Goal Calculator"
      description="Calculate time to reach savings goal"
      resultLabel="TIME TO GOAL"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Target Amount ($)</label>
          <input type="number" value={targetAmount} onChange={(e) => setTargetAmount(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Monthly Contribution ($)</label>
          <input type="number" value={monthlyContribution} onChange={(e) => setMonthlyContribution(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Annual Interest Rate (%)</label>
          <input type="number" value={annualInterestRate} onChange={(e) => setAnnualInterestRate(Number(e.target.value))} step="0.1" className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
