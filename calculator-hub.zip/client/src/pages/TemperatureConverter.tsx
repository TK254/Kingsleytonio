import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { convertTemperature } from '@/lib/calculators-extended';

export default function TemperatureConverter() {
  const [value, setValue] = useState(20);
  const [from, setFrom] = useState<'celsius' | 'fahrenheit' | 'kelvin'>('celsius');
  const [to, setTo] = useState<'celsius' | 'fahrenheit' | 'kelvin'>('fahrenheit');

  const result = useMemo(() => {
    return convertTemperature({ value, from, to });
  }, [value, from, to]);

  return (
    <CalculatorTemplate
      title="Temperature Converter"
      description="Convert between temperature units"
      resultLabel="CONVERTED TEMPERATURE"
      resultValue={result.formatted}
      resultUnit={`°${result.unit}`}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Value</label>
          <input type="number" value={value} onChange={(e) => setValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">From</label>
          <select value={from} onChange={(e) => setFrom(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="celsius">Celsius</option>
            <option value="fahrenheit">Fahrenheit</option>
            <option value="kelvin">Kelvin</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">To</label>
          <select value={to} onChange={(e) => setTo(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="celsius">Celsius</option>
            <option value="fahrenheit">Fahrenheit</option>
            <option value="kelvin">Kelvin</option>
          </select>
        </div>
      </div>
    </CalculatorTemplate>
  );
}
