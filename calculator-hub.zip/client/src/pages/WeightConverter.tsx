import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { convertWeight } from '@/lib/calculators-extended';

export default function WeightConverter() {
  const [value, setValue] = useState(1);
  const [from, setFrom] = useState<'mg' | 'g' | 'kg' | 'oz' | 'lb' | 'ton'>('kg');
  const [to, setTo] = useState<'mg' | 'g' | 'kg' | 'oz' | 'lb' | 'ton'>('lb');

  const result = useMemo(() => {
    return convertWeight({ value, from, to });
  }, [value, from, to]);

  return (
    <CalculatorTemplate
      title="Weight Converter"
      description="Convert between weight units"
      resultLabel="CONVERTED WEIGHT"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Value</label>
          <input type="number" value={value} onChange={(e) => setValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">From</label>
          <select value={from} onChange={(e) => setFrom(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="mg">Milligrams</option>
            <option value="g">Grams</option>
            <option value="kg">Kilograms</option>
            <option value="oz">Ounces</option>
            <option value="lb">Pounds</option>
            <option value="ton">Metric Tons</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">To</label>
          <select value={to} onChange={(e) => setTo(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="mg">Milligrams</option>
            <option value="g">Grams</option>
            <option value="kg">Kilograms</option>
            <option value="oz">Ounces</option>
            <option value="lb">Pounds</option>
            <option value="ton">Metric Tons</option>
          </select>
        </div>
      </div>
    </CalculatorTemplate>
  );
}
