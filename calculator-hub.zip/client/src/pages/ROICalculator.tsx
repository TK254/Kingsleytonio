import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateROI } from '@/lib/calculators-extended';

export default function ROICalculator() {
  const [initialInvestment, setInitialInvestment] = useState(10000);
  const [finalValue, setFinalValue] = useState(12000);

  const result = useMemo(() => {
    return calculateROI({ initialInvestment, finalValue });
  }, [initialInvestment, finalValue]);

  return (
    <CalculatorTemplate
      title="ROI Calculator"
      description="Calculate return on investment"
      resultLabel="ROI"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Initial Investment ($)</label>
          <input type="number" value={initialInvestment} onChange={(e) => setInitialInvestment(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Final Value ($)</label>
          <input type="number" value={finalValue} onChange={(e) => setFinalValue(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
