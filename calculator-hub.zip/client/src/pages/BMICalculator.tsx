/**
 * BMI Calculator Page
 * Design: Minimalist Precision
 */

import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { calculateBMI } from '@/lib/calculators';

export default function BMICalculator() {
  const [weight, setWeight] = useState(70); // kg
  const [height, setHeight] = useState(175); // cm
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');

  // Convert to metric if imperial
  const metricWeight = unit === 'imperial' ? weight * 0.453592 : weight;
  const metricHeight = unit === 'imperial' ? height * 2.54 : height;

  const result = useMemo(() => {
    return calculateBMI({ weight: metricWeight, height: metricHeight });
  }, [metricWeight, metricHeight]);

  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return 'text-blue-600';
    if (bmi < 25) return 'text-green-600';
    if (bmi < 30) return 'text-amber-600';
    return 'text-red-600';
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal weight';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">BMI Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Unit Toggle */}
          <div className="flex gap-2 mb-8">
            {(['metric', 'imperial'] as const).map((u) => (
              <Button
                key={u}
                onClick={() => setUnit(u)}
                variant={unit === u ? 'default' : 'outline'}
                className="capitalize"
              >
                {u === 'metric' ? 'Metric (kg, cm)' : 'Imperial (lbs, in)'}
              </Button>
            ))}
          </div>

          {/* Input Section */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Your Measurements
            </h2>

            {/* Weight */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-foreground mb-2">
                Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="range"
                  min={unit === 'metric' ? '30' : '66'}
                  max={unit === 'metric' ? '200' : '440'}
                  step="1"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="flex-grow"
                />
              </div>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
              />
            </div>

            {/* Height */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-foreground mb-2">
                Height ({unit === 'metric' ? 'cm' : 'inches'})
              </label>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="range"
                  min={unit === 'metric' ? '100' : '39'}
                  max={unit === 'metric' ? '250' : '98'}
                  step="1"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="flex-grow"
                />
              </div>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="border-precision px-3 py-2 rounded-lg w-full font-mono-display"
              />
            </div>
          </div>

          {/* Result Section */}
          <div className="border-precision bg-secondary rounded-lg p-8 mb-8">
            <h2 className="text-sm font-medium text-muted-foreground mb-4">
              YOUR BMI
            </h2>
            <div className={`font-mono-result ${getBMIColor(result.value)} mb-4`}>
              {result.formatted}
            </div>
            <div className="text-lg font-semibold text-foreground">
              {getBMICategory(result.value)}
            </div>
          </div>

          {/* BMI Chart */}
          <div className="border-precision bg-card rounded-lg p-8 mb-8">
            <h3 className="font-semibold text-foreground mb-6">BMI Categories</h3>
            <div className="space-y-3">
              {[
                { range: 'Below 18.5', category: 'Underweight', color: 'bg-blue-100 border-blue-300' },
                { range: '18.5 - 24.9', category: 'Normal weight', color: 'bg-green-100 border-green-300' },
                { range: '25 - 29.9', category: 'Overweight', color: 'bg-amber-100 border-amber-300' },
                { range: '30+', category: 'Obese', color: 'bg-red-100 border-red-300' },
              ].map((item, idx) => (
                <div key={idx} className={`border-precision ${item.color} p-4 rounded-lg`}>
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-foreground">{item.category}</span>
                    <span className="text-sm text-muted-foreground">{item.range}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* FAQ */}
          <div className="border-precision bg-card rounded-lg p-8">
            <h3 className="font-semibold text-foreground mb-4">FAQ</h3>
            <div className="space-y-4 text-sm">
              <div>
                <p className="font-medium text-foreground mb-1">What is BMI?</p>
                <p className="text-muted-foreground">
                  Body Mass Index (BMI) is a measure of body fat based on height and
                  weight that applies to adult men and women.
                </p>
              </div>
              <div>
                <p className="font-medium text-foreground mb-1">
                  Is BMI accurate for athletes?
                </p>
                <p className="text-muted-foreground">
                  BMI may overestimate body fat in athletes and underestimate it in
                  older adults. Consult a healthcare provider for personalized advice.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
