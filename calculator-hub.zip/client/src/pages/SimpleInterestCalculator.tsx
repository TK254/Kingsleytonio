import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateSimpleInterest } from '@/lib/calculators-extended';

export default function SimpleInterestCalculator() {
  const [principal, setPrincipal] = useState(1000);
  const [rate, setRate] = useState(5);
  const [time, setTime] = useState(2);

  const result = useMemo(() => {
    return calculateSimpleInterest({ principal, rate, time });
  }, [principal, rate, time]);

  return (
    <CalculatorTemplate
      title="Simple Interest Calculator"
      description="Calculate interest on savings"
      resultLabel="INTEREST EARNED"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Principal ($)</label>
          <input type="number" value={principal} onChange={(e) => setPrincipal(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Rate (% per year)</label>
          <input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} step="0.1" className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Time (Years)</label>
          <input type="number" value={time} onChange={(e) => setTime(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
