import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateWaterIntake } from '@/lib/calculators-extended';

export default function WaterIntakeCalculator() {
  const [weight, setWeight] = useState(70);
  const [activityLevel, setActivityLevel] = useState<'sedentary' | 'light' | 'moderate' | 'active'>('moderate');

  const result = useMemo(() => {
    return calculateWaterIntake({ weight, activityLevel });
  }, [weight, activityLevel]);

  return (
    <CalculatorTemplate
      title="Water Intake Calculator"
      description="Calculate daily water intake recommendations"
      resultLabel="DAILY WATER INTAKE"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Weight (kg)</label>
          <input type="number" value={weight} onChange={(e) => setWeight(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Activity Level</label>
          <select value={activityLevel} onChange={(e) => setActivityLevel(e.target.value as any)} className="border-precision px-4 py-3 rounded-lg w-full">
            <option value="sedentary">Sedentary</option>
            <option value="light">Light</option>
            <option value="moderate">Moderate</option>
            <option value="active">Active</option>
          </select>
        </div>
      </div>
    </CalculatorTemplate>
  );
}
