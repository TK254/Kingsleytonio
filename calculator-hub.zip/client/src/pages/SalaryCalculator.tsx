import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateSalary } from '@/lib/calculators-extended';

export default function SalaryCalculator() {
  const [annualSalary, setAnnualSalary] = useState(60000);
  const [taxRate, setTaxRate] = useState(20);
  const [deductions, setDeductions] = useState(0);

  const result = useMemo(() => {
    return calculateSalary({ annualSalary, taxRate, deductions });
  }, [annualSalary, taxRate, deductions]);

  return (
    <CalculatorTemplate
      title="Salary Calculator"
      description="Calculate net monthly salary"
      resultLabel="MONTHLY NET SALARY"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Annual Salary ($)</label>
          <input type="number" value={annualSalary} onChange={(e) => setAnnualSalary(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Tax Rate (%)</label>
          <input type="number" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Deductions ($)</label>
          <input type="number" value={deductions} onChange={(e) => setDeductions(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
