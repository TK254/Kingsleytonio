import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateLoan } from '@/lib/calculators-extended';

export default function LoanCalculator() {
  const [principal, setPrincipal] = useState(50000);
  const [annualRate, setAnnualRate] = useState(5.5);
  const [years, setYears] = useState(5);

  const result = useMemo(() => {
    return calculateLoan({ principal, annualRate, years });
  }, [principal, annualRate, years]);

  return (
    <CalculatorTemplate
      title="Loan Calculator"
      description="Calculate monthly loan payments"
      resultLabel="MONTHLY PAYMENT"
      resultValue={result.formatted}
      resultUnit={result.unit}
      faqItems={[
        {
          question: 'What is a loan?',
          answer: 'A loan is money borrowed from a lender that must be repaid with interest over a specified period.',
        },
        {
          question: 'How is monthly payment calculated?',
          answer: 'Monthly payment is calculated using the loan amount, interest rate, and loan term using the amortization formula.',
        },
      ]}
      infoSection={{
        title: 'About Loans',
        content: 'Loans are financial products where a lender provides money to a borrower who agrees to repay it with interest. Common types include personal loans, auto loans, and student loans.',
      }}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Loan Amount ($)
          </label>
          <input
            type="number"
            value={principal}
            onChange={(e) => setPrincipal(Number(e.target.value))}
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Annual Interest Rate (%)
          </label>
          <input
            type="number"
            value={annualRate}
            onChange={(e) => setAnnualRate(Number(e.target.value))}
            step="0.1"
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Loan Term (Years)
          </label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
