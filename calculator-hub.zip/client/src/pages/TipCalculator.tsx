import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateTip } from '@/lib/calculators-extended';

export default function TipCalculator() {
  const [billAmount, setBillAmount] = useState(50);
  const [tipPercentage, setTipPercentage] = useState(18);
  const [numberOfPeople, setNumberOfPeople] = useState(1);

  const result = useMemo(() => {
    return calculateTip({ billAmount, tipPercentage, numberOfPeople });
  }, [billAmount, tipPercentage, numberOfPeople]);

  return (
    <CalculatorTemplate
      title="Tip Calculator"
      description="Calculate tips for restaurants and services"
      resultLabel="TIP AMOUNT"
      resultValue={result.formatted}
      resultUnit={result.unit}
      faqItems={[
        {
          question: 'What is a standard tip percentage?',
          answer: 'Standard tip percentages are 15% for average service, 18% for good service, and 20%+ for excellent service.',
        },
        {
          question: 'Should I tip on pre-tax or post-tax?',
          answer: 'Most people tip on the pre-tax amount, but tipping on the total is also acceptable.',
        },
      ]}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Bill Amount ($)
          </label>
          <input
            type="number"
            value={billAmount}
            onChange={(e) => setBillAmount(Number(e.target.value))}
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Tip Percentage (%)
          </label>
          <div className="flex gap-2 mb-2">
            {[15, 18, 20].map((pct) => (
              <button
                key={pct}
                onClick={() => setTipPercentage(pct)}
                className={`px-3 py-2 rounded-lg border-precision text-sm font-medium transition-colors ${
                  tipPercentage === pct
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-secondary text-foreground hover:bg-muted'
                }`}
              >
                {pct}%
              </button>
            ))}
          </div>
          <input
            type="number"
            value={tipPercentage}
            onChange={(e) => setTipPercentage(Number(e.target.value))}
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Number of People
          </label>
          <input
            type="number"
            value={numberOfPeople}
            onChange={(e) => setNumberOfPeople(Number(e.target.value))}
            min="1"
            className="border-precision px-4 py-3 rounded-lg w-full font-mono-display"
          />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
