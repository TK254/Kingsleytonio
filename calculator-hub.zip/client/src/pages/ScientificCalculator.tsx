/**
 * Scientific Calculator Page
 * Design: Minimalist Precision
 */

import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Copy, RotateCcw } from 'lucide-react';
import { scientificCalculate } from '@/lib/calculators';
import { toast } from 'sonner';

export default function ScientificCalculator() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);

  const handleNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperation = (op: string) => {
    const currentValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(currentValue);
    } else if (operation) {
      const result = scientificCalculate(
        `${previousValue} ${operation} ${currentValue}`
      );
      setDisplay(result.toString());
      setPreviousValue(result);
    }

    setOperation(op);
    setWaitingForNewValue(true);
  };

  const handleEquals = () => {
    if (operation && previousValue !== null) {
      const currentValue = parseFloat(display);
      const result = scientificCalculate(
        `${previousValue} ${operation} ${currentValue}`
      );
      setDisplay(result.toString());
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const handleFunction = (func: string) => {
    const value = parseFloat(display);
    let result: number;

    switch (func) {
      case 'sqrt':
        result = Math.sqrt(value);
        break;
      case 'square':
        result = value * value;
        break;
      case 'sin':
        result = Math.sin((value * Math.PI) / 180);
        break;
      case 'cos':
        result = Math.cos((value * Math.PI) / 180);
        break;
      case 'tan':
        result = Math.tan((value * Math.PI) / 180);
        break;
      case 'log':
        result = Math.log10(value);
        break;
      case 'ln':
        result = Math.log(value);
        break;
      case 'exp':
        result = Math.exp(value);
        break;
      case 'factorial':
        result = factorial(value);
        break;
      default:
        result = value;
    }

    setDisplay(result.toString());
    setWaitingForNewValue(true);
  };

  const factorial = (n: number): number => {
    if (n < 0) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(display);
    toast.success('Copied to clipboard!');
  };

  const buttons = [
    ['C', 'DEL', '(', ')', '/'],
    ['7', '8', '9', '*', 'sqrt'],
    ['4', '5', '6', '-', 'x²'],
    ['1', '2', '3', '+', 'log'],
    ['0', '.', '=', 'sin', 'cos'],
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Scientific Calculator</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Display */}
          <div className="border-precision bg-card rounded-lg p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-muted-foreground">Result</p>
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors text-sm"
              >
                <Copy className="w-4 h-4" />
                Copy
              </button>
            </div>
            <div className="font-mono-result text-right text-foreground break-words">
              {display}
            </div>
          </div>

          {/* Calculator Grid */}
          <div className="border-precision bg-card rounded-lg p-6">
            <div className="grid grid-cols-5 gap-2 mb-4">
              {buttons.map((row, rowIdx) => (
                <div key={rowIdx} className="contents">
                  {row.map((btn) => {
                    let onClick: () => void;
                    let variant: 'default' | 'outline' | 'secondary' =
                      'outline';

                    if (btn === 'C') {
                      onClick = handleClear;
                      variant = 'secondary';
                    } else if (btn === 'DEL') {
                      onClick = () =>
                        setDisplay(
                          display.length > 1 ? display.slice(0, -1) : '0'
                        );
                      variant = 'secondary';
                    } else if (btn === '=') {
                      onClick = handleEquals;
                      variant = 'default';
                    } else if (['+', '-', '*', '/'].includes(btn)) {
                      onClick = () => handleOperation(btn);
                      variant = 'secondary';
                    } else if (
                      ['sqrt', 'x²', 'log', 'sin', 'cos'].includes(btn)
                    ) {
                      onClick = () => {
                        const funcMap: Record<string, string> = {
                          'x²': 'square',
                          sqrt: 'sqrt',
                          log: 'log',
                          sin: 'sin',
                          cos: 'cos',
                        };
                        handleFunction(funcMap[btn]);
                      };
                      variant = 'secondary';
                    } else if (['(', ')'].includes(btn)) {
                      onClick = () =>
                        setDisplay(display === '0' ? btn : display + btn);
                    } else {
                      onClick = () => handleNumber(btn);
                    }

                    return (
                      <Button
                        key={btn}
                        onClick={onClick}
                        variant={variant}
                        className="h-12 font-semibold"
                      >
                        {btn}
                      </Button>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Additional Functions */}
            <div className="grid grid-cols-5 gap-2">
              {['tan', 'ln', 'exp', 'n!', 'π'].map((btn) => (
                <Button
                  key={btn}
                  onClick={() => {
                    if (btn === 'π') {
                      setDisplay(Math.PI.toString());
                      setWaitingForNewValue(true);
                    } else if (btn === 'n!') {
                      handleFunction('factorial');
                    } else {
                      handleFunction(btn);
                    }
                  }}
                  variant="outline"
                  className="h-12 font-semibold text-sm"
                >
                  {btn}
                </Button>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div className="mt-12 border-precision bg-secondary rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              How to Use
            </h2>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <strong className="text-foreground">Basic Operations:</strong> Use
                +, -, *, / for addition, subtraction, multiplication, and division
              </li>
              <li>
                <strong className="text-foreground">Functions:</strong> Click sqrt,
                x², sin, cos, tan, log, ln, or n! for advanced calculations
              </li>
              <li>
                <strong className="text-foreground">Parentheses:</strong> Use ( and
                ) to group operations
              </li>
              <li>
                <strong className="text-foreground">Copy Result:</strong> Click the
                Copy button to save your result to clipboard
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
