import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculateBreakEven } from '@/lib/calculators-extended';

export default function BreakEvenCalculator() {
  const [fixedCosts, setFixedCosts] = useState(10000);
  const [variableCostPerUnit, setVariableCostPerUnit] = useState(5);
  const [pricePerUnit, setPricePerUnit] = useState(15);

  const result = useMemo(() => {
    return calculateBreakEven({ fixedCosts, variableCostPerUnit, pricePerUnit });
  }, [fixedCosts, variableCostPerUnit, pricePerUnit]);

  return (
    <CalculatorTemplate
      title="Break Even Calculator"
      description="Calculate break-even point for business"
      resultLabel="BREAK EVEN UNITS"
      resultValue={result.formatted}
      resultUnit={result.unit}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Fixed Costs ($)</label>
          <input type="number" value={fixedCosts} onChange={(e) => setFixedCosts(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Variable Cost Per Unit ($)</label>
          <input type="number" value={variableCostPerUnit} onChange={(e) => setVariableCostPerUnit(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Price Per Unit ($)</label>
          <input type="number" value={pricePerUnit} onChange={(e) => setPricePerUnit(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
