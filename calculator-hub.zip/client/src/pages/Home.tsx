/**
 * Calculator Hub - Home Page
 * Design: Minimalist Precision
 * A clean, grid-based interface emphasizing clarity and function
 */

import { Link } from 'wouter';
import { Calculator, DollarSign, Heart, Percent, TrendingUp, Calendar, Zap, Utensils, Briefcase, TrendingDown, Thermometer, Ruler, Weight, Sigma } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CalculatorCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  href: string;
}

const calculators: CalculatorCard[] = [
  {
    id: 'scientific',
    title: 'Scientific',
    description: 'Advanced math operations',
    icon: <Calculator className="w-6 h-6" />,
    color: 'from-indigo-500 to-indigo-600',
    href: '/scientific',
  },
  {
    id: 'mortgage',
    title: 'Mortgage',
    description: 'Calculate monthly payments',
    icon: <DollarSign className="w-6 h-6" />,
    color: 'from-blue-500 to-blue-600',
    href: '/mortgage',
  },
  {
    id: 'bmi',
    title: 'BMI',
    description: 'Body mass index calculator',
    icon: <Heart className="w-6 h-6" />,
    color: 'from-rose-500 to-rose-600',
    href: '/bmi',
  },
  {
    id: 'percentage',
    title: 'Percentage',
    description: 'Quick percentage calculations',
    icon: <Percent className="w-6 h-6" />,
    color: 'from-emerald-500 to-emerald-600',
    href: '/percentage',
  },
  {
    id: 'compound-interest',
    title: 'Compound Interest',
    description: 'Investment growth calculator',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'from-amber-500 to-amber-600',
    href: '/compound-interest',
  },
  {
    id: 'age',
    title: 'Age',
    description: 'Calculate your exact age',
    icon: <Calendar className="w-6 h-6" />,
    color: 'from-purple-500 to-purple-600',
    href: '/age',
  },
  {
    id: 'loan',
    title: 'Loan',
    description: 'Calculate loan payments',
    icon: <DollarSign className="w-6 h-6" />,
    color: 'from-cyan-500 to-cyan-600',
    href: '/loan',
  },
  {
    id: 'tip',
    title: 'Tip',
    description: 'Calculate tips and splits',
    icon: <Utensils className="w-6 h-6" />,
    color: 'from-orange-500 to-orange-600',
    href: '/tip',
  },
  {
    id: 'discount',
    title: 'Discount',
    description: 'Calculate sale prices',
    icon: <TrendingDown className="w-6 h-6" />,
    color: 'from-pink-500 to-pink-600',
    href: '/discount',
  },
  {
    id: 'simple-interest',
    title: 'Simple Interest',
    description: 'Calculate interest earned',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'from-green-500 to-green-600',
    href: '/simple-interest',
  },
  {
    id: 'markup',
    title: 'Markup',
    description: 'Calculate selling prices',
    icon: <Briefcase className="w-6 h-6" />,
    color: 'from-indigo-500 to-indigo-600',
    href: '/markup',
  },
  {
    id: 'profit-margin',
    title: 'Profit Margin',
    description: 'Calculate profit margins',
    icon: <Percent className="w-6 h-6" />,
    color: 'from-blue-500 to-blue-600',
    href: '/profit-margin',
  },
  {
    id: 'roi',
    title: 'ROI',
    description: 'Calculate return on investment',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'from-emerald-500 to-emerald-600',
    href: '/roi',
  },
  {
    id: 'water-intake',
    title: 'Water Intake',
    description: 'Daily hydration calculator',
    icon: <Utensils className="w-6 h-6" />,
    color: 'from-sky-500 to-sky-600',
    href: '/water-intake',
  },
  {
    id: 'ideal-weight',
    title: 'Ideal Weight',
    description: 'Calculate ideal weight range',
    icon: <Heart className="w-6 h-6" />,
    color: 'from-rose-500 to-rose-600',
    href: '/ideal-weight',
  },
  {
    id: 'salary',
    title: 'Salary',
    description: 'Calculate net salary',
    icon: <Briefcase className="w-6 h-6" />,
    color: 'from-purple-500 to-purple-600',
    href: '/salary',
  },
  {
    id: 'break-even',
    title: 'Break Even',
    description: 'Calculate break-even point',
    icon: <Zap className="w-6 h-6" />,
    color: 'from-yellow-500 to-yellow-600',
    href: '/break-even',
  },
  {
    id: 'debt-payoff',
    title: 'Debt Payoff',
    description: 'Calculate payoff timeline',
    icon: <TrendingDown className="w-6 h-6" />,
    color: 'from-red-500 to-red-600',
    href: '/debt-payoff',
  },
  {
    id: 'savings-goal',
    title: 'Savings Goal',
    description: 'Calculate savings timeline',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'from-green-500 to-green-600',
    href: '/savings-goal',
  },
  {
    id: 'temperature',
    title: 'Temperature',
    description: 'Convert temperature units',
    icon: <Thermometer className="w-6 h-6" />,
    color: 'from-orange-500 to-orange-600',
    href: '/temperature-converter',
  },
  {
    id: 'length',
    title: 'Length',
    description: 'Convert length units',
    icon: <Ruler className="w-6 h-6" />,
    color: 'from-blue-500 to-blue-600',
    href: '/length-converter',
  },
  {
    id: 'weight',
    title: 'Weight',
    description: 'Convert weight units',
    icon: <Weight className="w-6 h-6" />,
    color: 'from-slate-500 to-slate-600',
    href: '/weight-converter',
  },
  {
    id: 'power',
    title: 'Power',
    description: 'Calculate powers and exponents',
    icon: <Sigma className="w-6 h-6" />,
    color: 'from-indigo-500 to-indigo-600',
    href: '/power',
  },
  {
    id: 'percentage-change',
    title: 'Percentage Change',
    description: 'Calculate percentage increase/decrease',
    icon: <Percent className="w-6 h-6" />,
    color: 'from-emerald-500 to-emerald-600',
    href: '/percentage-change',
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <Calculator className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Calculator Hub</h1>
                <p className="text-sm text-muted-foreground">
                  The Ultimate Online Math Suite
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-background to-secondary py-12">
        <div className="container">
          <div className="max-w-2xl">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              Fast, Accurate Calculations
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Access a collection of specialized calculators for finance, health, math, and more.
              All completely free, no registration required.
            </p>
            <div className="flex gap-4">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90">
                <Link href="/scientific">Get Started</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="#calculators">Explore All</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid */}
      <section id="calculators" className="py-16">
        <div className="container">
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Our Calculators
            </h2>
            <p className="text-muted-foreground">
              26 specialized calculators covering finance, health, math, and conversions
            </p>
          </div>

          <div className="grid-calc">
            {calculators.map((calc) => (
              <Link key={calc.id} href={calc.href}>
                <a className="group">
                  <div className="border-precision card-hover p-6 h-full flex flex-col bg-card hover:bg-secondary transition-colors">
                    {/* Icon */}
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${calc.color} flex items-center justify-center text-white mb-4 group-hover:shadow-lg transition-shadow`}
                    >
                      {calc.icon}
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {calc.title}
                    </h3>
                    <p className="text-sm text-muted-foreground flex-grow mb-4">
                      {calc.description}
                    </p>

                    {/* Arrow */}
                    <div className="text-accent font-semibold text-sm group-hover:translate-x-1 transition-transform">
                      Use Calculator →
                    </div>
                  </div>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-secondary py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">
            Why Choose Calculator Hub?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Lightning Fast',
                description:
                  'Instant calculations with zero latency. Get results in milliseconds.',
              },
              {
                title: 'Completely Free',
                description:
                  'No ads, no registration, no hidden fees. Pure calculation power.',
              },
              {
                title: 'Highly Accurate',
                description:
                  'Precision-engineered algorithms ensure accurate results every time.',
              },
              {
                title: 'Mobile Friendly',
                description:
                  'Works seamlessly on all devices. Calculate on the go.',
              },
              {
                title: 'Privacy First',
                description:
                  'All calculations happen locally. Your data never leaves your device.',
              },
              {
                title: 'Always Available',
                description:
                  'No downtime. Access our calculators 24/7 from anywhere.',
              },
            ].map((feature, idx) => (
              <div key={idx} className="border-precision p-6 bg-card rounded-lg">
                <h3 className="font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2026 Calculator Hub. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-accent hover:text-accent/80 transition-colors">
                About
              </a>
              <a href="#" className="text-accent hover:text-accent/80 transition-colors">
                Privacy
              </a>
              <a href="#" className="text-accent hover:text-accent/80 transition-colors">
                Terms
              </a>
              <a href="#" className="text-accent hover:text-accent/80 transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
