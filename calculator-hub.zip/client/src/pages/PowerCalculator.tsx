import { useState, useMemo } from 'react';
import { CalculatorTemplate } from '@/components/CalculatorTemplate';
import { calculatePower } from '@/lib/calculators-extended';

export default function PowerCalculator() {
  const [base, setBase] = useState(2);
  const [exponent, setExponent] = useState(3);

  const result = useMemo(() => {
    return calculatePower(base, exponent);
  }, [base, exponent]);

  return (
    <CalculatorTemplate
      title="Power Calculator"
      description="Calculate powers and exponents"
      resultLabel="RESULT"
      resultValue={result.formatted}
    >
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Base</label>
          <input type="number" value={base} onChange={(e) => setBase(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Exponent</label>
          <input type="number" value={exponent} onChange={(e) => setExponent(Number(e.target.value))} className="border-precision px-4 py-3 rounded-lg w-full font-mono-display" />
        </div>
      </div>
    </CalculatorTemplate>
  );
}
