/**
 * Generic Calculator Template Component
 * Reusable template for creating new calculator pages quickly
 */

import { ReactNode } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Copy } from 'lucide-react';
import { toast } from 'sonner';

interface CalculatorTemplateProps {
  title: string;
  description: string;
  children: ReactNode;
  resultLabel?: string;
  resultValue?: string | number;
  resultUnit?: string;
  onCopyResult?: () => void;
  faqItems?: Array<{
    question: string;
    answer: string;
  }>;
  infoSection?: {
    title: string;
    content: string;
  };
}

export function CalculatorTemplate({
  title,
  description,
  children,
  resultLabel = 'RESULT',
  resultValue,
  resultUnit,
  onCopyResult,
  faqItems,
  infoSection,
}: CalculatorTemplateProps) {
  const handleCopy = () => {
    if (onCopyResult) {
      onCopyResult();
    } else if (resultValue) {
      navigator.clipboard.writeText(resultValue.toString());
      toast.success('Copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4 flex items-center gap-4">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back
            </a>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Input Section */}
          <div className="border-precision bg-card rounded-lg p-8">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Calculate
            </h2>
            {children}
          </div>

          {/* Result & Info Section */}
          <div className="space-y-8">
            {/* Result Display */}
            {resultValue !== undefined && (
              <div className="border-precision bg-secondary rounded-lg p-8">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-sm font-medium text-muted-foreground">
                    {resultLabel}
                  </h2>
                  <button
                    onClick={handleCopy}
                    className="inline-flex items-center gap-2 text-accent hover:text-accent/80 transition-colors text-sm"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </button>
                </div>
                <div className="font-mono-result text-accent mb-2">
                  {resultValue}
                </div>
                {resultUnit && (
                  <p className="text-sm text-muted-foreground">{resultUnit}</p>
                )}
              </div>
            )}

            {/* FAQ Section */}
            {faqItems && faqItems.length > 0 && (
              <div className="border-precision bg-card rounded-lg p-8">
                <h3 className="font-semibold text-foreground mb-4">FAQ</h3>
                <div className="space-y-4 text-sm">
                  {faqItems.map((item, idx) => (
                    <div key={idx}>
                      <p className="font-medium text-foreground mb-1">
                        {item.question}
                      </p>
                      <p className="text-muted-foreground">{item.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Info Section */}
            {infoSection && (
              <div className="border-precision bg-card rounded-lg p-8">
                <h3 className="font-semibold text-foreground mb-4">
                  {infoSection.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {infoSection.content}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
