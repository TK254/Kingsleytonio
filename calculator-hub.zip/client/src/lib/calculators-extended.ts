/**
 * Calculator Hub: Extended calculator functions
 * Additional 20+ specialized calculators for finance, health, math, and utilities
 */

export interface CalculatorResult {
  value: number;
  formatted: string;
  unit?: string;
}

/* ==================== FINANCE CALCULATORS ==================== */

export interface LoanInput {
  principal: number;
  annualRate: number;
  years: number;
}

export const calculateLoan = (input: LoanInput): CalculatorResult => {
  const { principal, annualRate, years } = input;
  const monthlyRate = annualRate / 100 / 12;
  const numberOfPayments = years * 12;

  if (monthlyRate === 0) {
    const monthlyPayment = principal / numberOfPayments;
    return {
      value: monthlyPayment,
      formatted: `$${monthlyPayment.toFixed(2)}`,
      unit: 'per month',
    };
  }

  const monthlyPayment =
    (principal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
    (Math.pow(1 + monthlyRate, numberOfPayments) - 1);

  return {
    value: monthlyPayment,
    formatted: `$${monthlyPayment.toFixed(2)}`,
    unit: 'per month',
  };
};

/* Simple Interest Calculator */
export interface SimpleInterestInput {
  principal: number;
  rate: number;
  time: number;
}

export const calculateSimpleInterest = (input: SimpleInterestInput): CalculatorResult => {
  const { principal, rate, time } = input;
  const interest = (principal * rate * time) / 100;
  const amount = principal + interest;

  return {
    value: interest,
    formatted: `$${interest.toFixed(2)}`,
    unit: `(Total: $${amount.toFixed(2)})`,
  };
};

/* Tip Calculator */
export interface TipInput {
  billAmount: number;
  tipPercentage: number;
  numberOfPeople?: number;
}

export const calculateTip = (input: TipInput): CalculatorResult => {
  const { billAmount, tipPercentage, numberOfPeople = 1 } = input;
  const tipAmount = (billAmount * tipPercentage) / 100;
  const totalPerPerson = (billAmount + tipAmount) / numberOfPeople;

  return {
    value: tipAmount,
    formatted: `$${tipAmount.toFixed(2)}`,
    unit: `($${totalPerPerson.toFixed(2)} per person)`,
  };
};

/* Discount Calculator */
export interface DiscountInput {
  originalPrice: number;
  discountPercentage: number;
}

export const calculateDiscount = (input: DiscountInput): CalculatorResult => {
  const { originalPrice, discountPercentage } = input;
  const discountAmount = (originalPrice * discountPercentage) / 100;
  const finalPrice = originalPrice - discountAmount;

  return {
    value: finalPrice,
    formatted: `$${finalPrice.toFixed(2)}`,
    unit: `(Save: $${discountAmount.toFixed(2)})`,
  };
};

/* Markup Calculator */
export interface MarkupInput {
  costPrice: number;
  markupPercentage: number;
}

export const calculateMarkup = (input: MarkupInput): CalculatorResult => {
  const { costPrice, markupPercentage } = input;
  const markupAmount = (costPrice * markupPercentage) / 100;
  const sellingPrice = costPrice + markupAmount;

  return {
    value: sellingPrice,
    formatted: `$${sellingPrice.toFixed(2)}`,
    unit: `(Markup: $${markupAmount.toFixed(2)})`,
  };
};

/* Profit Margin Calculator */
export interface ProfitMarginInput {
  revenue: number;
  cost: number;
}

export const calculateProfitMargin = (input: ProfitMarginInput): CalculatorResult => {
  const { revenue, cost } = input;
  const profit = revenue - cost;
  const margin = (profit / revenue) * 100;

  return {
    value: margin,
    formatted: `${margin.toFixed(2)}%`,
    unit: `(Profit: $${profit.toFixed(2)})`,
  };
};

/* ==================== HEALTH & FITNESS CALCULATORS ==================== */

export interface CalorieIntakeInput {
  weight: number;
  height: number;
  age: number;
  gender: 'male' | 'female';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'veryActive';
}

export const calculateDailyCalories = (input: CalorieIntakeInput): CalculatorResult => {
  const { weight, height, age, gender, activityLevel } = input;

  let bmr: number;
  if (gender === 'male') {
    bmr = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age;
  } else {
    bmr = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age;
  }

  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    veryActive: 1.9,
  };

  const tdee = bmr * (activityMultipliers[activityLevel] || 1.2);

  return {
    value: tdee,
    formatted: tdee.toFixed(0),
    unit: 'calories/day',
  };
};

/* Ideal Weight Calculator */
export interface IdealWeightInput {
  height: number;
  gender: 'male' | 'female';
}

export const calculateIdealWeight = (input: IdealWeightInput): CalculatorResult => {
  const { height, gender } = input;
  // Devine formula
  let weight: number;
  if (gender === 'male') {
    weight = 50 + 2.3 * ((height - 60) / 12);
  } else {
    weight = 45.5 + 2.3 * ((height - 60) / 12);
  }

  return {
    value: weight,
    formatted: `${weight.toFixed(1)} lbs`,
    unit: '(±10% is healthy)',
  };
};

/* Water Intake Calculator */
export interface WaterIntakeInput {
  weight: number; // kg
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active';
}

export const calculateWaterIntake = (input: WaterIntakeInput): CalculatorResult => {
  const { weight, activityLevel } = input;
  const baseIntake = weight * 35; // ml per kg

  const activityMultipliers: Record<string, number> = {
    sedentary: 1,
    light: 1.1,
    moderate: 1.25,
    active: 1.5,
  };

  const totalMl = baseIntake * (activityMultipliers[activityLevel] || 1);
  const liters = totalMl / 1000;
  const cups = totalMl / 236.588;

  return {
    value: liters,
    formatted: `${liters.toFixed(1)} L`,
    unit: `(${cups.toFixed(1)} cups)`,
  };
};

/* ==================== MATH CALCULATORS ==================== */

/* GCD Calculator */
export const calculateGCD = (a: number, b: number): CalculatorResult => {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b !== 0) {
    const temp = b;
    b = a % b;
    a = temp;
  }
  return {
    value: a,
    formatted: a.toString(),
    unit: '',
  };
};

/* LCM Calculator */
export const calculateLCM = (a: number, b: number): CalculatorResult => {
  const gcd = calculateGCD(a, b).value;
  const lcm = (Math.abs(a) * Math.abs(b)) / gcd;
  return {
    value: lcm,
    formatted: lcm.toString(),
    unit: '',
  };
};

/* Power Calculator */
export const calculatePower = (base: number, exponent: number): CalculatorResult => {
  const result = Math.pow(base, exponent);
  return {
    value: result,
    formatted: result.toFixed(4),
    unit: '',
  };
};

/* Percentage Increase/Decrease */
export interface PercentageChangeInput {
  oldValue: number;
  newValue: number;
}

export const calculatePercentageChange = (input: PercentageChangeInput): CalculatorResult => {
  const { oldValue, newValue } = input;
  const change = ((newValue - oldValue) / oldValue) * 100;
  return {
    value: change,
    formatted: change.toFixed(2),
    unit: '%',
  };
};

/* ==================== CONVERSION CALCULATORS ==================== */

/* Temperature Converter */
export interface TemperatureInput {
  value: number;
  from: 'celsius' | 'fahrenheit' | 'kelvin';
  to: 'celsius' | 'fahrenheit' | 'kelvin';
}

export const convertTemperature = (input: TemperatureInput): CalculatorResult => {
  const { value, from, to } = input;
  let celsius = value;

  // Convert to Celsius first
  if (from === 'fahrenheit') {
    celsius = (value - 32) * (5 / 9);
  } else if (from === 'kelvin') {
    celsius = value - 273.15;
  }

  // Convert from Celsius to target
  let result = celsius;
  if (to === 'fahrenheit') {
    result = celsius * (9 / 5) + 32;
  } else if (to === 'kelvin') {
    result = celsius + 273.15;
  }

  return {
    value: result,
    formatted: result.toFixed(2),
    unit: to.charAt(0).toUpperCase(),
  };
};

/* Length Converter */
export interface LengthInput {
  value: number;
  from: 'mm' | 'cm' | 'm' | 'km' | 'in' | 'ft' | 'yd' | 'mi';
  to: 'mm' | 'cm' | 'm' | 'km' | 'in' | 'ft' | 'yd' | 'mi';
}

export const convertLength = (input: LengthInput): CalculatorResult => {
  const { value, from, to } = input;

  const toMeters: Record<string, number> = {
    mm: 0.001,
    cm: 0.01,
    m: 1,
    km: 1000,
    in: 0.0254,
    ft: 0.3048,
    yd: 0.9144,
    mi: 1609.34,
  };

  const meters = value * toMeters[from];
  const result = meters / toMeters[to];

  return {
    value: result,
    formatted: result.toFixed(4),
    unit: to,
  };
};

/* Weight Converter */
export interface WeightInput {
  value: number;
  from: 'mg' | 'g' | 'kg' | 'oz' | 'lb' | 'ton';
  to: 'mg' | 'g' | 'kg' | 'oz' | 'lb' | 'ton';
}

export const convertWeight = (input: WeightInput): CalculatorResult => {
  const { value, from, to } = input;

  const toGrams: Record<string, number> = {
    mg: 0.001,
    g: 1,
    kg: 1000,
    oz: 28.3495,
    lb: 453.592,
    ton: 1000000,
  };

  const grams = value * toGrams[from];
  const result = grams / toGrams[to];

  return {
    value: result,
    formatted: result.toFixed(4),
    unit: to,
  };
};

/* ==================== UTILITY CALCULATORS ==================== */

/* GPA Calculator */
export interface GradeInput {
  grade: string;
  creditHours: number;
}

export const calculateGPA = (grades: GradeInput[]): CalculatorResult => {
  const gradePoints: Record<string, number> = {
    'A+': 4.0, A: 4.0, 'A-': 3.7,
    'B+': 3.3, B: 3.0, 'B-': 2.7,
    'C+': 2.3, C: 2.0, 'C-': 1.7,
    'D+': 1.3, D: 1.0, 'D-': 0.7,
    F: 0.0,
  };

  let totalPoints = 0;
  let totalCredits = 0;

  grades.forEach((g) => {
    const points = gradePoints[g.grade] || 0;
    totalPoints += points * g.creditHours;
    totalCredits += g.creditHours;
  });

  const gpa = totalCredits > 0 ? totalPoints / totalCredits : 0;

  return {
    value: gpa,
    formatted: gpa.toFixed(2),
    unit: 'GPA',
  };
};

/* Salary Calculator */
export interface SalaryInput {
  annualSalary: number;
  taxRate: number;
  deductions: number;
}

export const calculateSalary = (input: SalaryInput): CalculatorResult => {
  const { annualSalary, taxRate, deductions } = input;
  const taxes = (annualSalary * taxRate) / 100;
  const netSalary = annualSalary - taxes - deductions;
  const monthlySalary = netSalary / 12;

  return {
    value: monthlySalary,
    formatted: `$${monthlySalary.toFixed(2)}`,
    unit: 'per month',
  };
};

/* ROI Calculator */
export interface ROIInput {
  initialInvestment: number;
  finalValue: number;
}

export const calculateROI = (input: ROIInput): CalculatorResult => {
  const { initialInvestment, finalValue } = input;
  const roi = ((finalValue - initialInvestment) / initialInvestment) * 100;

  return {
    value: roi,
    formatted: `${roi.toFixed(2)}%`,
    unit: `(Gain: $${(finalValue - initialInvestment).toFixed(2)})`,
  };
};

/* Break Even Calculator */
export interface BreakEvenInput {
  fixedCosts: number;
  variableCostPerUnit: number;
  pricePerUnit: number;
}

export const calculateBreakEven = (input: BreakEvenInput): CalculatorResult => {
  const { fixedCosts, variableCostPerUnit, pricePerUnit } = input;
  const contribution = pricePerUnit - variableCostPerUnit;
  const breakEvenUnits = fixedCosts / contribution;

  return {
    value: breakEvenUnits,
    formatted: breakEvenUnits.toFixed(0),
    unit: 'units',
  };
};

/* Debt Payoff Calculator */
export interface DebtPayoffInput {
  debtAmount: number;
  monthlyPayment: number;
  annualInterestRate: number;
}

export const calculateDebtPayoff = (input: DebtPayoffInput): CalculatorResult => {
  const { debtAmount, monthlyPayment, annualInterestRate } = input;
  const monthlyRate = annualInterestRate / 100 / 12;
  let balance = debtAmount;
  let months = 0;

  while (balance > 0 && months < 600) {
    const interestCharge = balance * monthlyRate;
    balance = balance + interestCharge - monthlyPayment;
    months++;
  }

  const years = (months / 12).toFixed(1);

  return {
    value: months,
    formatted: `${years} years`,
    unit: `(${months} months)`,
  };
};

/* Savings Goal Calculator */
export interface SavingsGoalInput {
  targetAmount: number;
  monthlyContribution: number;
  annualInterestRate: number;
}

export const calculateSavingsGoal = (input: SavingsGoalInput): CalculatorResult => {
  const { targetAmount, monthlyContribution, annualInterestRate } = input;
  const monthlyRate = annualInterestRate / 100 / 12;
  let balance = 0;
  let months = 0;

  while (balance < targetAmount && months < 600) {
    balance = balance * (1 + monthlyRate) + monthlyContribution;
    months++;
  }

  const years = (months / 12).toFixed(1);

  return {
    value: months,
    formatted: `${years} years`,
    unit: `(${months} months)`,
  };
};
