/**
 * Calculator Hub: Core calculation functions
 * Each calculator is a pure function for easy testing and reuse
 */

export interface CalculatorResult {
  value: number;
  formatted: string;
  unit?: string;
}

/* Scientific Calculator */
export const scientificCalculate = (expression: string): number => {
  try {
    // Simple eval-like calculator (in production, use math.js or similar)
    return Function('"use strict"; return (' + expression + ')')();
  } catch {
    return 0;
  }
};

/* Mortgage Calculator */
export interface MortgageInput {
  principal: number; // Loan amount
  annualRate: number; // Annual interest rate (%)
  years: number; // Loan term in years
}

export const calculateMortgage = (input: MortgageInput): CalculatorResult => {
  const { principal, annualRate, years } = input;
  const monthlyRate = annualRate / 100 / 12;
  const numberOfPayments = years * 12;

  if (monthlyRate === 0) {
    const monthlyPayment = principal / numberOfPayments;
    return {
      value: monthlyPayment,
      formatted: `$${monthlyPayment.toFixed(2)}`,
      unit: 'per month',
    };
  }

  const monthlyPayment =
    (principal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
    (Math.pow(1 + monthlyRate, numberOfPayments) - 1);

  return {
    value: monthlyPayment,
    formatted: `$${monthlyPayment.toFixed(2)}`,
    unit: 'per month',
  };
};

export const calculateMortgageTotal = (input: MortgageInput): number => {
  const monthlyPayment = calculateMortgage(input).value;
  return monthlyPayment * input.years * 12;
};

/* BMI Calculator */
export interface BMIInput {
  weight: number; // kg
  height: number; // cm
}

export const calculateBMI = (input: BMIInput): CalculatorResult => {
  const { weight, height } = input;
  const heightInMeters = height / 100;
  const bmi = weight / (heightInMeters * heightInMeters);

  let category = 'Normal weight';
  if (bmi < 18.5) category = 'Underweight';
  else if (bmi < 25) category = 'Normal weight';
  else if (bmi < 30) category = 'Overweight';
  else category = 'Obese';

  return {
    value: bmi,
    formatted: bmi.toFixed(1),
    unit: category,
  };
};

/* Percentage Calculator */
export interface PercentageInput {
  value: number;
  total: number;
}

export const calculatePercentage = (input: PercentageInput): CalculatorResult => {
  const { value, total } = input;
  const percentage = (value / total) * 100;

  return {
    value: percentage,
    formatted: percentage.toFixed(2),
    unit: '%',
  };
};

export const calculatePercentageOf = (
  percentage: number,
  total: number
): CalculatorResult => {
  const value = (percentage / 100) * total;

  return {
    value,
    formatted: value.toFixed(2),
    unit: '',
  };
};

/* Calorie Calculator */
export interface CalorieInput {
  weight: number; // kg
  height: number; // cm
  age: number; // years
  gender: 'male' | 'female';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'veryActive';
}

export const calculateCalories = (input: CalorieInput): CalculatorResult => {
  const { weight, height, age, gender, activityLevel } = input;

  // Harris-Benedict equation
  let bmr: number;
  if (gender === 'male') {
    bmr = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age;
  } else {
    bmr = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age;
  }

  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    veryActive: 1.9,
  };

  const tdee = bmr * (activityMultipliers[activityLevel] || 1.2);

  return {
    value: tdee,
    formatted: tdee.toFixed(0),
    unit: 'calories/day',
  };
};

/* Compound Interest Calculator */
export interface CompoundInterestInput {
  principal: number;
  rate: number; // Annual interest rate (%)
  time: number; // Years
  frequency: number; // Compounding frequency (1=annual, 2=semi-annual, 4=quarterly, 12=monthly)
}

export const calculateCompoundInterest = (
  input: CompoundInterestInput
): CalculatorResult => {
  const { principal, rate, time, frequency } = input;
  const amount =
    principal * Math.pow(1 + rate / 100 / frequency, frequency * time);
  const interest = amount - principal;

  return {
    value: interest,
    formatted: `$${interest.toFixed(2)}`,
    unit: 'interest earned',
  };
};

/* Age Calculator */
export const calculateAge = (birthDate: Date): CalculatorResult => {
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();

  if (
    monthDiff < 0 ||
    (monthDiff === 0 && today.getDate() < birthDate.getDate())
  ) {
    age--;
  }

  return {
    value: age,
    formatted: age.toString(),
    unit: 'years',
  };
};

/* GPA Calculator */
export interface GradeInput {
  grade: string; // 'A', 'B', 'C', etc.
  creditHours: number;
}

export const calculateGPA = (grades: GradeInput[]): CalculatorResult => {
  const gradePoints: Record<string, number> = {
    'A+': 4.0,
    A: 4.0,
    'A-': 3.7,
    'B+': 3.3,
    B: 3.0,
    'B-': 2.7,
    'C+': 2.3,
    C: 2.0,
    'C-': 1.7,
    'D+': 1.3,
    D: 1.0,
    'D-': 0.7,
    F: 0.0,
  };

  let totalPoints = 0;
  let totalCredits = 0;

  grades.forEach((g) => {
    const points = gradePoints[g.grade] || 0;
    totalPoints += points * g.creditHours;
    totalCredits += g.creditHours;
  });

  const gpa = totalCredits > 0 ? totalPoints / totalCredits : 0;

  return {
    value: gpa,
    formatted: gpa.toFixed(2),
    unit: 'GPA',
  };
};
