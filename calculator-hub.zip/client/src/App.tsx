import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ScientificCalculator from "./pages/ScientificCalculator";
import MortgageCalculator from "./pages/MortgageCalculator";
import BMICalculator from "./pages/BMICalculator";
import PercentageCalculator from "./pages/PercentageCalculator";
import CompoundInterestCalculator from "./pages/CompoundInterestCalculator";
import AgeCalculator from "./pages/AgeCalculator";
import LoanCalculator from "./pages/LoanCalculator";
import TipCalculator from "./pages/TipCalculator";
import DiscountCalculator from "./pages/DiscountCalculator";
import SimpleInterestCalculator from "./pages/SimpleInterestCalculator";
import MarkupCalculator from "./pages/MarkupCalculator";
import ProfitMarginCalculator from "./pages/ProfitMarginCalculator";
import ROICalculator from "./pages/ROICalculator";
import WaterIntakeCalculator from "./pages/WaterIntakeCalculator";
import IdealWeightCalculator from "./pages/IdealWeightCalculator";
import SalaryCalculator from "./pages/SalaryCalculator";
import BreakEvenCalculator from "./pages/BreakEvenCalculator";
import DebtPayoffCalculator from "./pages/DebtPayoffCalculator";
import SavingsGoalCalculator from "./pages/SavingsGoalCalculator";
import TemperatureConverter from "./pages/TemperatureConverter";
import LengthConverter from "./pages/LengthConverter";
import WeightConverter from "./pages/WeightConverter";
import PowerCalculator from "./pages/PowerCalculator";
import PercentageChangeCalculator from "./pages/PercentageChangeCalculator";


function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/scientific"} component={ScientificCalculator} />
      <Route path={"/mortgage"} component={MortgageCalculator} />
      <Route path={"/bmi"} component={BMICalculator} />
      <Route path={"/percentage"} component={PercentageCalculator} />
      <Route path={"/compound-interest"} component={CompoundInterestCalculator} />
      <Route path={"/age"} component={AgeCalculator} />
      <Route path={"/loan"} component={LoanCalculator} />
      <Route path={"/tip"} component={TipCalculator} />
      <Route path={"/discount"} component={DiscountCalculator} />
      <Route path={"/simple-interest"} component={SimpleInterestCalculator} />
      <Route path={"/markup"} component={MarkupCalculator} />
      <Route path={"/profit-margin"} component={ProfitMarginCalculator} />
      <Route path={"/roi"} component={ROICalculator} />
      <Route path={"/water-intake"} component={WaterIntakeCalculator} />
      <Route path={"/ideal-weight"} component={IdealWeightCalculator} />
      <Route path={"/salary"} component={SalaryCalculator} />
      <Route path={"/break-even"} component={BreakEvenCalculator} />
      <Route path={"/debt-payoff"} component={DebtPayoffCalculator} />
      <Route path={"/savings-goal"} component={SavingsGoalCalculator} />
      <Route path={"/temperature-converter"} component={TemperatureConverter} />
      <Route path={"/length-converter"} component={LengthConverter} />
      <Route path={"/weight-converter"} component={WeightConverter} />
      <Route path={"/power"} component={PowerCalculator} />
      <Route path={"/percentage-change"} component={PercentageChangeCalculator} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
